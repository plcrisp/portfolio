#include <bits/stdc++.h>

using namespace std;

int main(){
    int hi, hf, total;
    cin >> hi >> hf;
    if(hi>=hf){
        hf=hf+24;
    }
    total=hf-hi;
    cout << "O JOGO DUROU " << total << " HORA(S)" << endl;
	return 0;
}
