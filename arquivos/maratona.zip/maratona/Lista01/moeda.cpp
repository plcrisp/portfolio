#include <bits/stdc++.h>

using namespace std;

int main() {
    float n;
    cin >> n;

    int nInt = static_cast<int>(n); // obter apenas a parte inteira

    // NOTAS
    int notas[6]={100,50,20,10,5,2};
    int quantNotas[6]={0};

    // obter apenas a parte decimal
    float nDec, nFloat;
    nFloat = static_cast<float>(nInt);
    nDec = n - nFloat;

    // MOEDAS
    float moedas[6]={1.00,0.50,0.25,0.10,0.05,0.01};
    int quantMoedas[6]={0};

    // calculo e print da quantidade de notas
    cout << "NOTAS:" << endl;

    for(int i=0;i<6;i++){
        quantNotas[i]=nInt/notas[i];
        nInt = nInt % notas[i];
        cout << quantNotas[i] << " nota(s) de R$ " << notas[i] << ".00" << endl;
    }

    nDec += nInt + 0.005;

    // calculo e print quantidade de moedas
    cout << "MOEDAS:" << endl;

    for(int i=0;i<6;i++){
        if(nDec>=moedas[i]){
            quantMoedas[i]=nDec/moedas[i];
        }
        while(nDec>=moedas[i]){
            nDec = nDec - moedas[i];
        }
        cout << quantMoedas[i] << " moeda(s) de R$ " << fixed << setprecision(2) << moedas[i] << endl;
    }
    return 0;
}
