#include <bits/stdc++.h>

using namespace std;

int main(){
	int t, vel;
	float litros;
	cin >> t;
	cin >> vel;
	float tfloat=t, velfloat=vel;
	litros = (velfloat*tfloat)/12;
	cout << fixed << setprecision(3) << litros << endl;

	return 0;
}
