#include<bits/stdc++.h>
#define TAM 100010

using namespace std;

int main(){
    int a,b,i,c;
    int va[TAM], vb[TAM];
    
    while(true){
    	cin >> a >> b;
    	if((a==0)&&(b==0)){
    		break;
    	}
    	
    	memset(va, 0, sizeof(va));
    	memset(vb, 0, sizeof(vb));
    	
    	for(i=0;i<a;i++){
    		cin >> c;
    		va[c]++;
    	}
    	for(i=0;i<b;i++){
    		cin >> c;
    		vb[c]++;
    	}
    	a=0;
    	b=0;
    	for(i=0;i<TAM;i++){
    		if(va[i] && !vb[i]){
    			a++;
    		}
    		if(!va[i] && vb[i]){
    			b++;
    		}
    	}
    	
    	if(a>b){
    		cout << b << endl;
    	}else{
    		cout << a << endl;
    	}
    }
    
 return 0;
}

