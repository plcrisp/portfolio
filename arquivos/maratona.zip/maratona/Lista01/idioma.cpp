#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        int k;
        string x;
        cin >> k;
        int s=0;
        vector<string> idiomas;
        for(int i=0;i<k;i++){
            cin >> x;
            idiomas.push_back(x);
        }
        for(int i=0;i<k;i++){
            if(idiomas[0]!=idiomas[i]){
                s = 1;
                break;
            }
        }
        if(s==1){
            cout << "ingles" << endl;
        }else if(s==0){
            cout << idiomas[0] << endl;
        }
    }
	return 0;
}
