#include <bits/stdc++.h>

using namespace std;

bool encontrar(vector<int> v,int x){
        for(int i=0;i<v.size();i++){
            if(v[i]==x){
                return true;
            }
        }
        return false;
}

int main(){
    while(true){
        int a,b,aux;
        int i=0,j=0;
        cin >> a >> b;
        if(a==0&&b==0){
            break;
        }
        vector<int> cartasA;
        vector<int> cartasB;
        cartasA.clear();
        cartasB.clear();
        int trocas=0;
        for(int i=0;i<a;i++){
            cin >> aux;
            cartasA.push_back(aux);
        }
        for(int i=0;i<b;i++){
            cin >> aux;
            cartasB.push_back(aux);
        }

        for(int i=0;i<cartasA.size();i++){
            for(int j=0;j<cartasB.size();j++){
                if (cartasA[i] != cartasB[j] && !encontrar(cartasA, cartasB[j]) && !encontrar(cartasB, cartasA[i])) {
                    cartasA.erase(cartasA.begin() + i);
                    cartasB.erase(cartasB.begin() + j);
                    ++trocas;
                    i--;
                    j--;
                    break;
                }
            }
        }

        cout << trocas << endl;
    }
	return 0;
}

