#include <bits/stdc++.h>

using namespace std;

void heapfy( int *vet, int n, int i){
    int esq = 2*i+1;
    int dir = 2*i+2;
    int maior, aux;
    maior =i;
    if((esq < n) && (vet[esq] > vet[maior])){
        maior = esq;
    }
    if((dir < n) && (vet[dir] > vet[maior])){
        maior = dir;
    }

    if(maior != i){
        aux = vet[i];
        vet[i] = vet[maior];
        vet[maior] = aux;

        heapfy(vet,n,maior);
    }
}

void create_heap(int *vet, int n){
    for(int i = n/2-1; i >= 0; i--){
        heapfy(vet,n,i);
    }
}

int main(){
    int vet[10] = {15, 25, 13, 68, 41, 7, 21, 11, 42, 1};
    create_heap(vet, 10);

    for(int i=0;i<10;i++){
        cout << vet [i] << " ";
    }


    return 0;
}