#include <bits/stdc++.h>

using namespace std;

int main(){
    while(true){
        int n;
        int xDiv, yDiv;
        int x, y;
        cin >> n;
        if(n==0){
            break;
        }
        cin >> xDiv >> yDiv;
        for(int i=0;i<n;i++){
            cin >> x >> y;
            if(x==xDiv||y==yDiv){
                cout << "divisa" << endl;
            }else if(x>xDiv&&y>yDiv){
                cout << "NE" << endl;
            }else if(x<xDiv&&y>yDiv){
                cout << "NO" << endl;
            }else if(x>xDiv&&y<yDiv){
                cout << "SE" << endl;
            }else if(x<xDiv&&y<yDiv){
                cout << "SO" << endl;
            }
        }
    }
	return 0;
}
