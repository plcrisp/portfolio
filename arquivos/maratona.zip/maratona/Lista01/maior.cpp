#include <bits/stdc++.h>

using namespace std;

int main(){
    int v[3];
    int maior=v[0];
    cin >> v[0] >> v[1] >> v[2];
    for(int i=0;i<3;i++){
        if(v[i]>maior){
            maior = v[i];
        }
    }
    cout << maior << " eh o maior" << endl;

	return 0;
}

