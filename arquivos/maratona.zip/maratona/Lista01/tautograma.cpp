#include <bits/stdc++.h>

using namespace std;

int main() {
    while(true){
        string frase;
        char letra;
        int s=0, maiuscula;
        getline(cin, frase);
        if(frase[0]=='*'){
            break;
        }
        letra=frase[0];
        if(letra>=97){
            maiuscula=0;
        }else{
            maiuscula=1;
        }

        for(int i=0;i<(frase.size()-1);i++){
            if(frase[i]==' '){
                if(maiuscula==0){
                    if((frase[i+1]!=letra)&&(frase[i+1]!=letra-32)){
                        s = 1;
                        break;
                    }
                }else{
                    if((frase[i+1]!=letra)&&(frase[i+1]!=letra+32)){
                        s = 1;
                        break;
                    }
                }
            }
        }

        if(s==0){
            cout << "Y" << endl;
        }else{
            cout << "N" << endl;
        }
    }
    return 0;
}

