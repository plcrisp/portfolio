#include<bits/stdc++.h>
using namespace std;

int main(){
    int r1,r2,l,c,soma,dx,dy,d;
    
   
    while(cin>>l>>c>>r1>>r2) 
    {   
        soma=r1+r2;
        dx=l-r1-r2;
        dy=c-r1-r2;
        d=dx*dx+dy*dy;
        if(r1==0||r2==0||l==0||c==0) break;
        if(((2*r1)>l)||((2*r1)>c)){
            cout<<"N"<<endl;
           
            }
        else if(2*r2>l||2*r2>c){
            cout<<"N"<<endl;
          
            }  
        else if(d>=(soma*soma)){
        cout<<"S"<<endl;
        }else{
        cout<<"N"<<endl;
       
        }
        }


    return 0;
}