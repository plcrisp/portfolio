#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;

    int mais=0, menos=0;
    vector<string> nomes;

    string aux2;
    char aux;

    for(int i=0;i<n;i++){
        cin >> aux >> aux2;
        if(aux=='+'){
            mais++;
        }else if(aux=='-'){
            menos++;
        }

        nomes.push_back(aux2);
    }

    sort(nomes.begin(),nomes.end());

    for(int i=0;i<nomes.size();i++){
        cout << nomes[i] << endl;
    }
    cout << "Se comportaram: " << mais << " | " << "Nao se comportaram: " << menos << endl;
    return 0;
}