#include <bits/stdc++.h>

using namespace std;

int main(){
    int a, b, c;
	while(cin >> a >> b >> c){
        if(a!=b && a!=c && b==c){
            cout << "A" << endl;
        }else if(a==b && a!=c && b!=c){
            cout << "C" << endl;
        }else if(a!=b && a==c && b!=c){
            cout << "B" << endl;
        }else{
            cout << "*" << endl;
        }
    }
	return 0;
}