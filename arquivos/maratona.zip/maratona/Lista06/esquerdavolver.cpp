#include <bits/stdc++.h>

using namespace std;

int main(){
	string comando;
	int aux=1000;
	int n=1, mod;
	while(true){
	    aux=1000;
        cin >> n;
        if(n==0){
            break;
        }
        cin >> comando;
        for(int i=0;i<n;i++){
            if(comando[i]=='E'){
                aux--;
            }
            if(comando[i]=='D'){
                aux++;
            }
        }
        mod = aux % 4;
        switch(mod){
            case 0:
                cout << 'N' << endl;
                break;
            case 1:
                cout << 'L' << endl;
                break;
            case 2:
                cout << 'S' << endl;
                break;
            case 3:
                cout << 'O' << endl;
                break;
        }
	}
	return 0;
}