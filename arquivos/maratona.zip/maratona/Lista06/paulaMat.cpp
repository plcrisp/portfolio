#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        string linha;
        cin >> linha;
        int a, b;
        a = linha[0] - '0';
        b = linha[2] - '0';
        if(a==b){
            cout << a*b << endl;
        }else if(linha[1]<95){
            cout << b-a << endl;
        }else{
            cout << a+b << endl;
        }
    }
    return 0;
}
