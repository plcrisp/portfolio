#include <bits/stdc++.h>

using namespace std;

void conversorBin(string a){
    int dec=0;
    for(int i=0;i<a.size();i++){
        if(a[i]=='1'){
            dec+=pow(2,(a.size()-1-i));
        }
    }
    cout << dec << " dec" << endl;

    string hex;

    while (dec > 0) {
        int resto = dec % 16;
        
        if (resto < 10) {
            hex = char('0' + resto) + hex;
        } else {
            hex = char('A' + (resto - 10)) + hex;
        }
        
        dec /= 16;
    }

    cout << hex << " hex" << endl;
}

void conversorDec(string a){
    int dec=0;
    dec=stoi(a);
    bitset<32> binaryValue(dec);

    string hex;

    while (dec > 0) {
        int resto = dec % 16;
        
        if (resto < 10) {
            hex = char('0' + resto) + hex;
        } else {
            hex = char('A' + (resto - 10)) + hex;
        }
        
        dec /= 16;
    }

    cout << hex << " hex" << endl;

    string binaryString = binaryValue.to_string(); 

    
    size_t firstOne = binaryString.find('1');
    
    if (firstOne != string::npos) {
        binaryString = binaryString.substr(firstOne);
    }

    cout << binaryString << " bin" << endl;
}

void conversorHex(string a){
    int decimal=0;
    for(int i=0;i<a.size();i++){
        if(a[i]=='a' || a[i]=='b' || a[i]=='c' || a[i]=='d' || a[i]=='e' || a[i]=='f'){
            decimal += (pow(16,(a.size()-1-i)))* ((a[i] - 'a') + 10);
        }else{
            decimal += (pow(16,(a.size()-1-i)))* (a[i] - '0');
        }
    }
    cout << decimal << " dec" << endl;

    bitset<32> binaryValue(decimal);
    string binaryString = binaryValue.to_string(); 

    
    size_t firstOne = binaryString.find('1');
    
    if (firstOne != string::npos) {
        binaryString = binaryString.substr(firstOne);
    }

    cout << binaryString << " bin" << endl;
}

int main(){
    int n;
    int cont=1;
    cin >> n;
    for(int i=0;i<n;i++){
        string num, base;
        cin >> num >> base;
        cout << "Case " << cont << ":" << endl;
        if(base=="hex"){
            conversorHex(num);
        }else if(base=="bin"){
            conversorBin(num);
        }else if(base=="dec"){
            conversorDec(num);
        }
        cout << "\n\n";
        cont++;
    }
    return 0;
}






int tribonacci(int r){
    int vet[r-1];
    vet[0]=0;
    vet[1]=1;
    vet[2]=1;

    for(int i=3;i<=r;i++){
        vet[r]=vet[r-1]+vet[r-2]+vet[r-3];
    }
    return vet[r];
}