#include <bits/stdc++.h>

using namespace std;

bool compara(string a, string b) {
    if (a.size() != b.size()) {
        return a.size() > b.size();
    }
    return false;
}



int main(){
    int n;
    cin >> n;
    cin.ignore();

    string s,s2;
    char c;
    vector<string> frase;

    for(int i=0;i<n;i++){
        getline(cin,s);
        for(int j=0;j<s.size();j++){
            if(s[j]!=' ' && s[j]!='\0'){
                s2.push_back(s[j]);
            }else{
                frase.push_back(s2);
                s2.clear();
            }
        }
        frase.push_back(s2);


        sort(frase.begin(),frase.end(),compara);

        for(int j=0;j<frase.size()-1;j++){
            cout << frase[j] << " ";
        }
        cout << frase[frase.size()-1] << endl;

        frase.clear();
        s.clear();
        s2.clear();
    }

    
    

    return 0;
}