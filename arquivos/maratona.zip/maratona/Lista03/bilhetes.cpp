#include <bits/stdc++.h>

using namespace std;

int main(){
	while(true){
        int n, m;
        cin >> n >> m;

        int aux,falsos=0;

        if((n==0)&&(m==0)){
            break;
        }
        
        vector<int> ocorrencia;

        for(int i=0;i<n+1;i++){
            ocorrencia.push_back(0);
        }

        for(int i=0;i<m;i++){
            cin >> aux;
            ocorrencia[aux]++;
        }

        for(int i=0;i<ocorrencia.size();i++){
            if(ocorrencia[i]>1){
                falsos++;
            }
        }
        cout << falsos << endl;
    }	
	return 0;
}
