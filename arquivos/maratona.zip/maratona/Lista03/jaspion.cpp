#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
    cin >> n;
    for(int i=0;i<n;i++){
        map<string,string> dicionario;
        vector<string> letra;

        string aux1, aux2;
        char aux;
        int m, n;

        cin >> m >> n;

        for(int j=0;j<m;j++){
            cin >> aux1;
            cin.ignore();
            getline(cin,aux2);
            dicionario.insert(make_pair(aux1,aux2));
        }

        aux1.clear();
        aux2.clear();

        for(int j=0;j<n;j++){
            getline(cin,aux1);
            int k=0;
            while(aux1[k]!='\0'){
                if(aux1[k]!=' '){
                    aux2.push_back(aux1[k]);
                }else{
                    letra.push_back(aux2);
                    aux2.clear();
                }
                k++;
            }
            letra.push_back(aux2);

            auto it = dicionario.find(letra[0]);

            if(it!=dicionario.end()){
                    cout  << dicionario[letra[0]];
                }else{
                    cout  << letra[0];
            }


            for(int j=1;j<letra.size();j++){
                it = dicionario.find(letra[j]);

                if(it!=dicionario.end()){
                    cout << " " << dicionario[letra[j]];
                }else{
                    cout << " " << letra[j];
                }
            }
            cout << endl;
            letra.clear();
            aux1.clear();
            aux2.clear();
        }

        cout << endl;

        dicionario.clear();
        letra.clear();


    }
	return 0;
}
