#include<bits/stdc++.h>

using namespace std;

int main(){
    int tamanho;
    cin >> tamanho;


    for(int i=1;i<=tamanho;i++){
        for(int esp=tamanho-i;esp>0;esp--){
            cout << " ";
        }
        for(int folha=i-1;folha>0;folha--){
            cout << "*";
        }
        cout << "|";
        for(int folha=i-1;folha>0;folha--){
            cout << "*";
        }
        for(int esp=tamanho-i;esp>0;esp--){
            cout << " ";
        }
        cout << endl;
    }
}
