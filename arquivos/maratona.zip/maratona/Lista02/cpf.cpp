#include <bits/stdc++.h>

using namespace std;

int main(){
	vector<int> cpf;
	string scpf;
	int aux, ver1=0, ver2=0,j;
	while(cin >> scpf){
		int k=0;
		ver1=0;
		ver2=0;
		for (int i = 0; i < scpf.size(); i++) {
    			if (isdigit(scpf[i])) {
        			aux = scpf[i] - '0';
        			cpf.push_back(aux);
    			}
		}
		for(int j=9;j>0;j--){
			ver2+=cpf[k]*j;
			k++;
		}
		for(int i=1;i<=9;i++){	
			ver1+=cpf[(i-1)]*i;
		}
		ver1 = ver1%11;
		ver2 = ver2%11;
		if(ver1==10){
			ver1 = 0;
		}
		if(ver2==10){
			ver2 = 0;
		}
		if((ver1==cpf[9])&&(ver2==cpf[10])){
			cout << "CPF valido" << endl;
		}else{
			cout << "CPF invalido" << endl;
		}
		scpf.clear();
		cpf.clear();
	}
	return 0;
}