#include <bits/stdc++.h>

using namespace std;

int main(){
	int teste=1;
	while(true){
		int x1, y1, x2, y2;
		cin >> x1 >> y1 >> x2 >> y2;
		if((x1==0)&&(y1==0)&&(x2==0)&&(y2==0)){
			break;
		}
		int quant, mx, my, num=0;
		cin >> quant;
		for(int i=0; i<quant; i++){
			cin >> mx >> my;
			if((((mx>=x1)&&(mx<=x2))||((mx<=x1)&&(mx>=x2)))&&(((my>=y1)&&(my<=y2))||((my<=y1)&&(my>=y2)))){
				num++;
			}
		}
		cout << "Teste " << teste << endl;
		cout << num << endl;
		teste++;
	}
	return 0;
}