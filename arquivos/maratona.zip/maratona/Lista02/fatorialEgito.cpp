#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        string excl;
        int val;
        long long int fat=1;
        cin >> val >> excl;
        for(int j=val;j >= 1;j-=excl.size()){
            fat = fat * j;
        }
        cout << fat << endl;
    }
    return 0;
}
