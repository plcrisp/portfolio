#include <bits/stdc++.h>

using namespace std;

int main(){
	int t;
	cin >> t;
	for(int i=0;i<t;i++){
		int quant,aux,meio;
		cin >> quant;
		vector<int> idade;
		for(int j=0;j<quant;j++){
			cin >> aux;
			idade.push_back(aux);
		}
		meio = (quant/2);
		cout << "Case " << i+1 << ": " << idade[meio] << endl;
	}
	return 0;
}