#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	for(int i=0;i<n;i++){
		int numTiros;
		cin >> numTiros;
		vector<int> posicao;
		string pulos;
		int acertos=0;
		for(int j=0;j<numTiros;j++){
			int aux;
			cin >> aux;
			posicao.push_back(aux);
		}
		cin >> pulos;
		for(int j=0;j<numTiros;j++){
			if((pulos[j]=='S')&&((posicao[j]==1)||(posicao[j]==2))){
				acertos++;
			}
			if((pulos[j]=='J')&&(posicao[j]>2)){
				acertos++;
			}
		}
		cout << acertos << endl;
		posicao.clear();
		pulos.clear();
	}
	return 0;
}