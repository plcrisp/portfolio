#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	cin.ignore();
	for(int i=0;i<n;i++){
		vector<string> compras;
		int umSo=0;
		string compra,aux;
		getline(cin,compra);
		for(int j=0;j<compra.size();j++){
			if(compra[j]!=' '){
				aux.push_back(compra[j]);
			}else{
				compras.push_back(aux);
				aux.clear();
				umSo=1;
			}
		}
		if(!aux.empty()){
			compras.push_back(aux);
			aux.clear();
		}
		if(umSo==0){
			compras.push_back(compra);
		}
		sort(compras.begin(),compras.end());

		vector<string>::iterator it;
		it = unique(compras.begin(),compras.end());
		compras.resize(distance(compras.begin(), it));

		for(int j=0;j<compras.size();j++){
			if(j!=(compras.size()-1)){
				cout << compras[j] << " ";
			}else{
				cout << compras[j] << endl;
			}
		}
		compras.clear();
		aux.clear();
		compra.clear();
	}
	return 0;
}