#include <bits/stdc++.h>
#define PI 3.1415

using namespace std;

int main(){
	while(true){
		int l, c, r1, r2, areaPara;
		float areaCilindros;
		cin >> l >> c >> r1 >> r2;
		if((l==0)&&(c==0)&&(r1==0)&&(r2==0)){
			break;
		}
		areaPara=l*c;
		areaCilindros = ((r1*r1*PI)+(r2*r2*PI));
		if((((2*r1)+(2*r2))<=l)||(((2*r1)+(2*r2))<=c)||(areaCilindros<=areaPara)){
			cout << "S" << endl;
		}else{
			cout << "N" << endl;
		}
	}
	return 0;
}