#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	for(int i=0;i<n;i++){
		string num;
		cin >> num;
		int leds = 0;
		int ledsEx[10] = {6,2,5,5,4,5,6,3,7,6};
		vector<int> digitos;
		for(char c : num){
			int digito = c - '0';
			digitos.push_back(digito);
		}
		for(int j=0;j<digitos.size();j++){
			leds += ledsEx[digitos[j]];	
		}
		cout << leds << " leds" << endl;
		digitos.clear();
		num.clear();
	}
	return 0;
}