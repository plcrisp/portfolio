#include <bits/stdc++.h>

using namespace std;

int main(){
	while(true){
		int a, d;
		cin >> a >> d;
		if((a==0)&&(d==0)){
			break;
		}
		vector<int> posicaoDef;
		vector<int> posicaoAta;
		for(int i=0;i<a;i++){
			int aux;
			cin >> aux;
			posicaoAta.push_back(aux);
		}
		for(int i=0;i<d;i++){
			int aux1;
			cin >> aux1;
			posicaoDef.push_back(aux1);
		}
		sort(posicaoAta.begin(),posicaoAta.end());
		sort(posicaoDef.begin(),posicaoDef.end());
		if(posicaoAta[0]>=posicaoDef[1]){
			cout << "N" << endl;
		}else{
			cout << "Y" << endl;
		}
	}
	return 0;
}