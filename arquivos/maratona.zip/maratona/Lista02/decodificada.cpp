#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	cin >> n;
	cin.ignore()
	for(int i=0;i<n;i++){
		string mensagem;
		getline(cin, mensagem);
		string decodificada;
		if(mensagem[0]!=' '){
			decodificada.push_back(mensagem[0]);
		}
		for(int j=0;j<mensagem.size();j++){
			if(mensagem[j]==' '){
				if((mensagem[j+1]>=97)&&(mensagem[j+1]<=122)){
					decodificada.push_back(mensagem[j+1]);
				}
			}
		}
		for(int j=0;j<decodificada.size();j++){
			cout << decodificada[j];
		}
		cout << endl;
		mensagem.clear();
		decodificada.clear();
	}
	return 0;
}