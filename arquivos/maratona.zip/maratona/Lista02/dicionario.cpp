#include <bits/stdc++.h>

using namespace std;

int main(){
	string linha, aux;
	int cont=0;
	vector<string> palavras;
	while(getline(cin,linha)){
		for(int i=0;i<linha.size();i++){
			if(((linha[i]>=97)&&(linha[i]<=122))||((linha[i]>=65)&&(linha[i]<=90))){
				linha[i] = tolower(linha[i]);
				aux.push_back(linha[i]);
			}else{
				palavras.push_back(aux);
				aux.clear();
			}
		}
		if(!aux.empty()){
			palavras.push_back(aux);
			aux.clear();
		}
		cont++;
	}
	sort(palavras.begin(),palavras.end());
	vector<string>::iterator it;
	it = unique(palavras.begin(),palavras.end());
	palavras.resize(distance(palavras.begin(), it));
	
	if(cont==1){
		for(int i=0;i<palavras.size();i++){
			cout << palavras[i] << endl;
		}
	}else{
		for(int i=1;i<palavras.size();i++){
			cout << palavras[i] << endl;
		}
	}
	return 0;
}